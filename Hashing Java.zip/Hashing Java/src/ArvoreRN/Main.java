package ArvoreRN;

public class Main {

    public static final int totalnodos = 100; // Nodos a serem inseridos randomicamente
    public static final int MAX = 2147483647; // 2^31 - 1 (para testes)

    public static void main(String args[]) {
/*
        Random gerador = new Random(); // Para gerar números aleatórios
        long inicio, aux, media = 0, total;
        int chave;

        ArvoreRN n50 = new ArvoreRN();
        ArvoreRN a = new ArvoreRN();

        inicio = System.nanoTime(); // Contagem de tempo total

        // Inserir totalnodos nodos
        for(int i = 0; i < totalnodos; i++) {
            a.inserir(gerador.nextInt(MAX));
        }
        // Buscar 10000 nodos
        for (int i = 0; i <= 10000; i++) {
            a.encontra(gerador.nextInt(MAX));
        }
    }*/
        ArvoreRN arv = new ArvoreRN();
        arv.inserir(10);
        arv.inserir(20);
        arv.inserir(12);
        arv.inserir(25);
        arv.print();
    }
}
