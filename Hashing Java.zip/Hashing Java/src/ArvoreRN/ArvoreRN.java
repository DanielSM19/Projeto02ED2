package ArvoreRN;
//@autor Daniel Santos Monteiro
public class ArvoreRN {

    public RNNodo raiz; // Uma árvore sempre terá um RNNodo raiz, que fica no nível mais alto da árvore
    // e é este RNNodo que é dado por "inicial" na árvore
    public static RNNodo nil = new RNNodo(0, false); // RNNodo sentinela. Todos os RNNodos no último nível da árvore apontarão para a sentinela
    // que é sempre de cor preta com valor 0
    public Integer cont;

    public ArvoreRN() {
        this.raiz = ArvoreRN.nil;
    }

    public ArvoreRN(int v) {
        this.raiz = new RNNodo(v, false);
    }

    // As rotações (rotacao_esq e rotacao_dir) servem para manter o balanceamento da árvore,
// especialmente porque a árvore preta e cormelha tem como característica o balanceamento
    private void rotacao_esq(RNNodo x) {
        RNNodo y = x.dir;
        x.dir = y.esq;
        if (y.esq != ArvoreRN.nil) y.esq.p = x;
        y.p = x.p;
        if (x.p == ArvoreRN.nil) this.raiz = y;
        else if (x == x.p.esq) x.p.esq = y;
        else x.p.dir = y;
        y.esq = x;
        x.p = y;
    }
    // Ambas as rotações são idênticas, sendo trocados apenas os "dir" e "esq", referentes a direita e esquerda
    private void rotacao_dir(RNNodo x) {
        RNNodo y = x.esq;
        x.esq = y.dir;
        if (y.dir != ArvoreRN.nil) y.dir.p = x;
        y.p = x.p;
        if (x.p == ArvoreRN.nil) this.raiz = y;
        else if (x == x.p.esq) x.p.esq = y;
        else x.p.dir = y;
        y.dir = x;
        x.p = y;
    }

    public void inserir (int n) {
        // Método que inserir um novo RNNodo com valor n (passado como parâmetro)
        // na árvore que está rodando
        if (this.raiz == ArvoreRN.nil) {
            // Se a árvore ainda esticor vazia, cria o RNNodo preto e o torna raiz
            this.raiz = new RNNodo (n, false);
        } else {
            // Se a árvore já conter um ou mais RNNodos, faremos uma busca (com o método encontra())
            // para locaizar o local em que o RNNodo decorá ser inserirdo (isso depende do valor do RNNodo)
            // pois os RNNodos com valores mais altos ficarão à direita da árvore e os com valores mais baixos à esquerda,
            // ficando, então, ordenados
            RNNodo a = this.encontra(n);
            if (n < a.v) {
                // Caso o valor do novo RNNodo seja menor do que o RNNodo encontrado, será inserirdo à esquerda do mesmo
                a.esq = new RNNodo(n, true);
                a.esq.p = a;
                this.fixaadicao(a.esq);
                // Ao final, deve ser chamado o método fixaadicao, que irá corrigir os possíveis casos
                // de desbalanceamento que podem ocorrer
            }	else if (n > a.v) {
                // Caso o valor do novo RNNodo seja maior do que o RNNodo encontrado, será inserirdo à direita do mesmo
                a.dir = new RNNodo(n, true);
                a.dir.p = a;
                this.fixaadicao(a.dir);
                // Ao final, deve ser chamado o método fixaadicao, que irá corrigir os possíveis casos
                // de desbalanceamento que podem ocorrer
            }
        }
    }

    public void transplant (RNNodo x, RNNodo y) {
        // Realiza troca entre os nós, sendo necessária ao se remocor um RNNodo para evitar perda de ponteiros
        if (x.p == ArvoreRN.nil) this.raiz = y;
        else if (x == x.p.esq) x.p.esq = y;
        else x.p.dir = y;
        y.p = x.p;
    }

    private void fixaadicao(RNNodo z) {
        RNNodo y;
        while (z.p.cor) {
            if (z.p == z.p.p.esq) {
                y = z.p.p.dir;
                if (y.cor) { // caso 1 (tio é cormelho):
                    // muda a cor do pai e do tio para preto e dos avós para cormelho.
                    // Então, sobe dois níveis na árvore.
                    z.p.cor = false;
                    y.cor = false;
                    z.p.p.cor = true;
                    z = z.p.p;
                }	else { // Ou seja, tio é preto
                    if (z == z.p.dir) { // caso 2
                        z = z.p;
                        this.rotacao_esq(z);
                    }
                    // caso 3
                    z.p.cor = false;
                    z.p.p.cor = true;
                    this.rotacao_dir(z.p.p);
                }
            }	else {
                y = z.p.p.esq;
                if (y.cor) { // caso 1
                    y.cor = z.p.cor = false;
                    z.p.p.cor = true;
                    z = z.p.p;
                }	else {
                    if (z == z.p.esq) { // caso 2
                        z = z.p;
                        this.rotacao_dir(z);
                    }
                    // caso 3
                    z.p.cor = false;
                    z.p.p.cor = true;
                    this.rotacao_esq(z.p.p);
                }
            }
        }
        this.raiz.cor = false;
    }

    public void remove(int n) {
        // Método que irá remocor o RNNodo que conter o valor passado como parâmetro
        RNNodo z = this.encontra(n);
        // Após utilizar o método encontra(), z será o RNNodo a ser excluído, caso ele exista, ou o com valor mais próximo de n
        // Caso não exista RNNodo com o valor n, o primeiro if do método já será quebrado e então não fará mais nada
        RNNodo x, y = z;
        boolean cordey = y.cor;

        if(z.v == n) {
            if (z.esq == ArvoreRN.nil) {
                x = z.dir;
                this.transplant(z, z.dir);
            } else if (z.dir == ArvoreRN.nil) {
                x = z.esq;
                this.transplant(z, z.esq);
            }	else {
                y = z.sucessor();
                cordey = y.cor;
                x = y.dir;

                if (y.p == z) x.p = y;
                else {
                    this.transplant(y, y.dir);
                    y.dir = z.dir;
                    y.dir.p = y;
                }
                this.transplant(z, y);
                y.esq = z.esq;
                y.esq.p = y;
                y.cor = z.cor;
            }

            if (!cordey) this.fixaremocao(x);
        }
    }

    private void fixaremocao(RNNodo n) {
        RNNodo x;

        while (n != this.raiz && !n.cor) {
            if (n == n.p.esq) {
                x = n.p.dir;

                if (x.cor) { // caso 1
                    x.cor = false;
                    n.p.cor = true;
                    this.rotacao_esq(n.p);
                    x = n.p.dir;
                }
                if (!x.esq.cor && !x.dir.cor) { // caso 2
                    x.cor = true;
                    n = n.p;
                } else {
                    if (!x.dir.cor) { // caso 3
                        x.esq.cor = false;
                        x.cor = true;
                        this.rotacao_dir(x);
                        x = n.p.dir;
                    }
                    // caso 4
                    x.cor = n.p.cor;
                    n.p.cor = false;
                    x.dir.cor = false;
                    this.rotacao_esq(n.p);
                    n = this.raiz;
                }
            }	else {
                x = n.p.esq;

                if (x.cor) { // caso 1
                    x.cor = false;
                    n.p.cor = true;
                    this.rotacao_dir(n.p);
                    x = n.p.esq;
                }
                if (!x.esq.cor && !x.dir.cor) { // caso 2
                    x.cor = true;
                    n = n.p;
                }	else {
                    if (!x.esq.cor) { // caso 3
                        x.dir.cor = false;
                        x.cor = true;
                        this.rotacao_esq(x);
                        x = n.p.esq;
                    }
                    // caso 4
                    x.cor = n.p.cor;
                    n.p.cor = false;
                    x.esq.cor = false;
                    this.rotacao_dir(n.p);
                    n = this.raiz;
                }
            }
        }
        n.cor = false;
    }

    public ArvoreRN encontra50(int n) {
        ArvoreRN res = new ArvoreRN();
        cont = 0;

        this.raiz.encontra50(cont, n, res);

        return res;
    }

    public void inorderWalk() {
        this.raiz.inorderWalk();
    }
    public RNNodo minimo() {
        return this.raiz.minimo();
    }

    public RNNodo maximo() {
        return this.raiz.maximo();
    }

    public RNNodo encontra (int n) {
        return this.raiz.encontra(n);
    }

    void print() {
        print(raiz);
    };

    void print(RNNodo n) {
        if (n != null) {
            String v = (n.v == 0) ? "nil" : n.v + "";
            System.out.print(v + "[" + color(n.cor) + "] -->");
            print(n.esq);
            print(n.dir);
        }
    }

    String color(boolean flag) {
        return (flag) ? "RED" : "BLACK";
    }
}
