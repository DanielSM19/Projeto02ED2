package ArvoreRN;

public class  RNNodo {

    public Integer v; // Um valor inteiro, que será a chave para busca, inserção, remoção...
    public RNNodo p, esq, dir; // Um RNNodo que representa o pai do RNRNNodo em questão,
    // o RNRNNodo que se encontra à esquerda e o que se encontra à direita do mesmo
    public boolean cor; // Uma flag booleana, que quando ticor valor "true",
    // significará que o RNNodo em questão é de cor cormelha, caso contrário é preto

/*  public RNRNNodo(int n){
		this.v = n;
		this.cor = false;
		this.esq = this.dir = this.p = null;
	} */

    public RNNodo(int n, boolean cor) {
        this.v = n;
        this.cor = cor;
        this.p = this.esq = this.dir = ArvoreRN.nil;
    }

    public RNNodo encontra(int n) {
        // Encontra o RNNodo que contém o valor que foi enviado como parâmetro, ou o mais próximo disso
        // Bem útil para encontrar o local em que será colocado um novo RNRNNodo com determinado valor :p
        if (n < this.v && this.esq != ArvoreRN.nil) return this.esq.encontra(n);
        else if (n > this.v && this.dir != ArvoreRN.nil) return this.dir.encontra(n);
        else return this;
    }

    public RNNodo minimo() {
        // Vai mostrar o valor mais baixo presente na árvore a partir do RNNodo que está rodando no momento
        if (this.esq != ArvoreRN.nil) return esq.minimo();
        else return this;
    }

    public RNNodo maximo() {
        // Vai mostrar o valor mais alto presente na árvore a partir do RNRNNodo que está rodando no momento
        if (this.dir != ArvoreRN.nil) return dir.maximo();
        else return this;
    }

    public void inorderWalk() {
        // Deve percorrer a minha árvore e printar
        // os valores de todos os RNNodos pertencentes a ela
        // de forma ordenada
        if (this.esq != ArvoreRN.nil) this.esq.inorderWalk();
        System.out.println(this.v);
        if (this.dir != ArvoreRN.nil) this.dir.inorderWalk();
    }

    public RNNodo predecessor() {
        // Informa o valor do RNRNNodo que antecede (em termos de valores)
        // o atual RNNodo
        if (this.esq != ArvoreRN.nil) return this.esq.maximo();
        else return this;
    }

    public RNNodo sucessor(){
        // Informa o valor do RNNodo que sucede (em termos de valores)
        // o atual RNRNNodo
        if (this.dir != ArvoreRN.nil) return this.dir.minimo();
        else return this;
    }

    // a corificar
    public void encontra50(Integer q, int aux, ArvoreRN res) {
        if(q >= 50) return;

        if (this.esq != ArvoreRN.nil) {
            this.esq.encontra50(q, aux, res);
        }
        if (this.v > aux && q < 50) {
            res.inserir(this.v);
            q++;
        }
        if (this.dir != ArvoreRN.nil) {
            this.dir.encontra50(q, aux, res);
        }
    }
}
