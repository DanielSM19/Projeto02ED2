package Hashing;
import ListaEncadeada.Lista;
public class HashLista {
    private Lista[] tab;
    private int numItens = 0, tam, tamAtual = 0;

    public HashLista(int tam) {
        tab = new Lista[tam];
        tam = tam;
        for(int i=0; i<tam; i++)   // inicializando
            tab[i] = null;
    }

    private int funcaohash(int chave) {
        int v = chave;
        return ( Math.abs(v) % tam );
    }

    public void insere(int valor) {
        int pos = funcaohash(valor);
        if ( tab[pos]!=null ) { // se esta ocupado
            if (tab[pos].busca_lista(valor)) { // verificando se a chave ja existe
                System.out.println(" *** ATENCAO O valor " + valor + " ja foi cadastrado ***");
                return;
            }
        }
        else  // se estiver livre
            tab[pos] = new Lista();
            tamAtual++;
            tab[pos].inserir(valor);
    }

    public void apaga(int chave) {
        int pos = busca(chave);
        if (pos != -1) {
            tab[pos].remover(chave);
            if(tab[pos] == null){
                tamAtual--;
            }
        }
        else System.out.println("\n valor nao encontrado");
    }

    public void imprime() {
        for (int i=0; i<tam; i++) {
            System.out.print("\n HASH[" + i + "] -> ");
            if ( tab[i]!=null )
                tab[i].imprime_lista();
            System.out.print("null");
        }
    }
    public int busca(int chave) {
        for (int i=0; i<tam; i++)
            if ( tab[i]!=null )
                if ( tab[i].busca_lista(chave) ) return i;
        return -1;
    }
    public int TableSize(){
        return numItens;
    }
}
