package Hashing;

import ArvoreRN.ArvoreRN;

public class HashRN {
    private ArvoreRN[] Arn;
    private int numItens = 0, tam, tamAtual = 0;

    public HashRN(int tamanho){
        tamAtual = 0;
        Arn = new ArvoreRN[tamanho];
        tam = tamanho;
    }

    public int funçãoHash(int i){
        return ( Math.abs(i) % tam );
    }
    public void inserirAVL(int i){
        int rest = funçãoHash(i);
        for(int x = 1; x < Arn.length; x++){
            if(x == rest){
                if (Arn[x] == null){
                    Arn[x] = new ArvoreRN();
                    tamAtual++;
                    verificaTam();
                }
                Arn[x].inserir(i);
                numItens++;
            }
        }
    }
    public void remover(int i){
        int rest = funçãoHash(i);
        for(int x = 0; x < Arn.length; x++){
            if(x == rest){
                if(Arn[x] == null){
                    System.out.printf("\n O valor inserido não existe na tabela\n");
                }else {
                    Arn[x].remove(i);
                    if(Arn[x] == null) {
                        numItens--;
                    }
                }
            }
        }
    }
   /*
    public void imprime(){
        for (int x = 0; x < Arn.length;x++){
            if(Arn[x] != null){
                Arn[x].pribt
            }
        }
    }*/
    public void printTabelaHash() {
        System.out.println("\nTabela Hash: ");
        if (Arn == null) {
            return;
        }
        for (int i = 0; i < tam; i++)
            System.out.println(Arn[i]);
        System.out.println();
    }
    public void verificaTam(){
        int i = (tam * 100)/60;
        if(i == tamAtual){
            System.out.printf("\nTabela 60% preenchida, redimencionando...\n");
            tam = tam * 2;
        }
    }
    public int TableSize(){
        return numItens;
    }

}

