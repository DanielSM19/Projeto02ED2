package Hashing;

import ArvoreAVL.ArvoreAVL;

public class HashAVL {
    private ArvoreAVL[] avl;
    private int numItens = 0, tam, tamAtual = 0;

    public HashAVL(int tamanho){
        tamAtual = 0;
        avl = new ArvoreAVL[tamanho];
        tam = tamanho;
    }

    public int funçãoHash(int i){
        return ( Math.abs(i) % tam );
    }
    public void inserirAVL(int i){
        int rest = funçãoHash(i);
        for(int x = 1; x < avl.length; x++){
            if(x == rest){
                if (avl[x] == null){
                    avl[x] = new ArvoreAVL();
                    tamAtual++;
                    verificaTam();
                }
                avl[x].inserir(i, avl[x].getRaiz());
                numItens++;
            }
        }
    }
    public void remover(int i){
        int rest = funçãoHash(i);
        for(int x = 0; x < avl.length; x++){
            if(x == rest){
                if(avl[x] == null){
                    System.out.printf("\n O valor inserido não existe na tabela\n");
                }else {
                    avl[x].remoção(i, avl[x].getRaiz());
                    if(avl[x] == null) {
                        numItens--;
                    }
                }
            }
        }
    }
    public void imprime(){
        for (int x = 0; x < avl.length;x++){
            if(avl[x] != null){
                avl[x].imprime(avl[x].getRaiz());
            }
        }
    }
    public void printTabelaHash() {
        System.out.println("\nTabela Hash: ");
        if (avl == null) {
            return;
        }
        for (int i = 0; i < tam; i++)
            System.out.println(avl[i]);
            System.out.println();
    }
    public void verificaTam(){
        int i = (tam * 100)/60;
        if(i == tamAtual){
            System.out.printf("\nTabela 60% preenchida, redimencionando...\n");
            tam = tam * 2;
        }
    }
    public int TableSize(){
        return numItens;
    }
}
