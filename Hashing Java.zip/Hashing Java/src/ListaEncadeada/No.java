package ListaEncadeada;

public class No {
    public int valor, chave;
    public No prox; // proximo no da lista

    public No(int  key, int valor) {
        valor=valor; } // construtor

    public void mostra() { System.out.print(valor + " -> "); }
}
