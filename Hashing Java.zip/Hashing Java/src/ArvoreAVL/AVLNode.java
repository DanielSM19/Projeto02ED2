package ArvoreAVL;

public class AVLNode {
    private int Info;
    private AVLNode pai;
    private AVLNode dir;
    private AVLNode esq;
    private int balanceamento;

    public AVLNode(int i) {
        dir = null;
        esq = null;
        pai = null;
        Info = i;
    }

    public int getBalanceamento() {
        return balanceamento;
    }

    public void setBalanceamento(int balanceamento) {
        this.balanceamento = balanceamento;
    }

    public AVLNode getPai() {
        return pai;
    }

    public void setPai(AVLNode pai) {
        this.pai = pai;
    }

    public int getInfo() {
        return Info;
    }

    public void setInfo(int Info) {
        this.Info = Info;
    }

    public AVLNode getDir() {
        return dir;
    }

    public void setDir(AVLNode dir) {
        this.dir = dir;
    }

    public AVLNode getEsq() {
        return esq;
    }

    public void setEsq(AVLNode esq) {
        this.esq = esq;
    }
}
