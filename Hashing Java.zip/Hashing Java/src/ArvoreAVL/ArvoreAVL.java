package ArvoreAVL;
//@autor Daniel Santos Monteiro
public class ArvoreAVL {

    private AVLNode raiz;

    public ArvoreAVL() {
        raiz = null;
    }

    public boolean isEmpty() {
        return raiz == null;
    }

    public AVLNode getRaiz() {
        return raiz;
    }
    //inserir e já balanceia usando o método de balancear
    public void inserir(int i, AVLNode atual) {
        if (isEmpty()) {//se vazio preenche a raiz
            AVLNode AVLNodevo = new AVLNode(i);
            raiz = AVLNodevo;
            defineFB(raiz);//define o fator de balanceamento de cada nó
        } else {
            if (i > atual.getInfo()) {
                if (atual.getDir() == null) {//se o AVLNode a ser inserido for maior que o atual e o da direita do atual for vazio, inserir la
                    AVLNode AVLNodevo = new AVLNode(i);
                    atual.setDir(AVLNodevo);
                    AVLNodevo.setPai(atual);
                    defineFB(raiz);//define o fator de balanceamento de cada nó
                    raiz = balanceia(raiz);//Balanceia a AVLTree
                } else { //senão, faz a recursão, passando o nó da direita do atual.
                    inserir(i, atual.getDir());
                }
            } else if (i < atual.getInfo()) { //mesma coisa aqui, só que com o nó da esquerda, se for meAVLNoder
                if (atual.getEsq() == null) {
                    AVLNode AVLNodevo = new AVLNode(i);
                    atual.setEsq(AVLNodevo);
                    AVLNodevo.setPai(atual);
                    defineFB(raiz);//define o fator de balanceamento de cada nó
                    raiz = balanceia(raiz);//Balanceia a AVLTree
                } else {
                    inserir(i, atual.getEsq());
                }
            } else {//se o nó já existir
                System.out.println("Impossível Inserir!");
            }
        }
    }
    //imprime todos os nós e mostra o fator de balanceamento de cada um
    public void imprime(AVLNode f) {
        if(isEmpty()){
            System.out.println("AVLTree vazia!");
        }else{
            System.out.println("Nó: " + f.getInfo() + " - Seu fator de balanceamento é: " + f.getBalanceamento());
            if (f.getDir() != null) {
                imprime(f.getDir());
            }
            if (f.getEsq() != null) {
                imprime(f.getEsq());
            }
        }
    }
    //remoeve e já balanceia usando o método de balancear
    public AVLNode remoção(int i, AVLNode atual) {
        if (isEmpty()) {//Se a AVLTree ticor vazia, nao faz nada
            System.out.println("AVLTree vazia!");
        } else if (i > atual.getInfo()) {//Se o valor a ser removido for maior q o do AVLNode atual, anda pra direita e atribui o retorAVLNode do metodo ao AVLNode direito passando ele mesmo como parametro
            atual.setDir(remoção(i, atual.getDir()));
        } else if (i < atual.getInfo()) {//se for meAVLNoder, faz a mesma coisa do passo anterior, só q indo pra esquerda
            atual.setEsq(remoção(i, atual.getEsq()));
        } else {//Se for igual, faz as corificações de remoção
            if (atual.getDir() == null && atual.getEsq() == null) {//se o nó não ticor subAVLTrees, ou seja, for uma folha, basta anular ele
                if(atual==raiz){
                    raiz=null;
                }else{
                    atual = null;
                }

            } else if (atual.getEsq() == null) {//se o nó atual só ticor a subAVLTree da direita, pega o valor da raiz dessa subAVLTree e substitui pelo atual
                atual = atual.getDir();
            } else if (atual.getDir() == null) {//se o atual ticor só a subAVLTree da esquerda,faz a mesma coisa , só que troca o nó pela raiz da direita
                atual = atual.getEsq();
            } else {//Se o nó ticor as duas subárvores, o bixo pega um pouco
                /*Cria um nó auxiliar pra percorrer a AVLTree até o valor mais a direita da subAVLTree da esquerda do nó atual
                 e seta ele como o valor da esquerda do atual*/
                AVLNode aux = atual.getEsq();
                while (aux.getDir() != null) {//Faz o aux ir até o valor mais a direita
                    aux = aux.getDir();
                }
                atual.setInfo(aux.getInfo()); //substitui o valor do nó atual pelo valor do auxiliar
                aux.setInfo(i); // substitui o valor do auxiliar pelo atual
                atual.setEsq(remoção(i, atual.getEsq()));//chama a recursão pra remoção o valor do atual, q agora tá AVLNode auxiliar, por isso, vai remoção o auxiliar
            }
        }
        if(raiz!=null){
            defineFB(raiz);//atualiza o fator de balanceamento de cada nó
            raiz = balanceia(raiz);//Balanceia a AVLTree
        }
        return atual;// retorna o atual
    }

    public int altura(AVLNode atual) {//corifica a altura de um determinado nó
        if (atual == null) {//Se o nó for nulo, sua altura será -1
            return -1;
        }
        if (atual.getDir() == null && atual.getEsq() == null) {//Se ele não ticor nenhum filho, sua altura será 0
            return 0;
        } else if (atual.getEsq() == null) {//Se o nó ticor apenas um filho, sua altura será 1 + a altura do nó filho
            return 1 + altura(atual.getDir());
        } else if (atual.getDir() == null) { //Mesma do passo anterior aqui
            return 1 + altura(atual.getEsq());
        } else { //Se ele ticor dois filhos, temos q corificar qual filho é mais "alto"
            if (altura(atual.getEsq()) > altura(atual.getDir())) {//a altura do nó será a soma de 1+ a altura do filho mais alto
                return 1 + altura(atual.getEsq());
            } else {
                return 1 + altura(atual.getDir());
            }
        }//e assim recursivamente, até chegar nas folhas q não terão filhos, a altura será 0 e assim a recursão para.
    }

    public void defineFB(AVLNode atual) {//Define o valor de balanceamento de cada nó com base na altura (adicionei um atributo pra armazenar o balanceamento na classe nó)
        atual.setBalanceamento(altura(atual.getEsq()) - altura(atual.getDir()));//O valor do balanceamendo será a altura do filho da direita meAVLNodes a altura do da direita
        if (atual.getDir() != null) {//corifica todos os nós
            defineFB(atual.getDir());
        }
        if (atual.getEsq() != null) {//corifica todos os nós
            defineFB(atual.getEsq());
        }
    }

    public AVLNode rotacaoADireita(AVLNode atual) {
        AVLNode aux = atual.getEsq(); //Armazena o valor do nó da esquerda do atual
        aux.setPai(atual.getPai());
        if (aux.getDir() != null) {//tratamento para quando a árvore é degenerada
            aux.getDir().setPai(atual);
        }
        atual.setPai(aux);
        atual.setEsq(aux.getDir());//Joga o valor da direita do nó da esquerda do atual, na esquerda do atual
        aux.setDir(atual);//troca o valor da direita do nó da esquerda pelo atual
        if (aux.getPai() != null) {//Se aux não for a raiz principal, configura o pai pra apontar pro AVLNodevo nó
            if (aux.getPai().getDir() == atual) {
                aux.getPai().setDir(aux);
            } else if (aux.getPai().getEsq() == atual) {
                aux.getPai().setEsq(aux);
            }
        }
        defineFB(aux);//atualiza o valor do balanceamento
        return aux; //retorna o valor do nó da esquerda q é o AVLNodevo pai
    }

    //mesma coisa do rotação a direita, só que incortido pra esquerda
    public AVLNode rotacaoAEsquerda(AVLNode atual) {
        AVLNode aux = atual.getDir();
        aux.setPai(atual.getPai());
        if (aux.getEsq() != null) {//tratamento para quando a árvore é degenerada
            aux.getEsq().setPai(atual);
        }

        atual.setPai(aux);
        atual.setDir(aux.getEsq());
        aux.setEsq(atual);
        if (aux.getPai() != null) {
            if (aux.getPai().getDir() == atual) {
                aux.getPai().setDir(aux);
            } else if (aux.getPai().getEsq() == atual) {
                aux.getPai().setEsq(aux);
            }
        }
        defineFB(aux);//atualiza o valor do balanceamento
        return aux;
    }

    public AVLNode rotacaoDuplaDireita(AVLNode atual) {
        AVLNode aux = atual.getEsq();//Armazena o valor do filho da esquerda
        atual.setEsq(rotacaoAEsquerda(aux));//faz uma rotação para a esquerda AVLNode filho da esquerda
        AVLNode aux2 = rotacaoADireita(atual); //Faz uma rotação para a direita AVLNode atual/pai com o filho da esquerda já rodado
        return aux2; //retorna o nó q será o AVLNodevo pai com seus filhos
    }

    //mesma coisa do de rotação dupla pra direita, só que incortido pra esquerda
    public AVLNode rotacaoDuplaEsquerda(AVLNode atual) {
        AVLNode aux = atual.getDir();
        atual.setDir(rotacaoADireita(aux));
        AVLNode aux2 = rotacaoAEsquerda(atual);
        return aux2;
    }

    public AVLNode balanceia(AVLNode atual) {//Recebe como parâmetro a raiz
        /*Se o nó atual ticor FB=2 e o seu filho da esquerda dele ticor Fb>=0,
         troca o valor dele pelo resultado da rotação a direita com ele*/
        if (atual.getBalanceamento() == 2 && atual.getEsq().getBalanceamento() >= 0) {
            atual = rotacaoADireita(atual);
            /* Senão se o nó atual ticor FB=-2 e o filho da direita dele ticor Fb<0,
             troca o valor dele pelo resultado da rotação a esquerda com ele*/
        } else if (atual.getBalanceamento() == -2 && atual.getDir().getBalanceamento() <= 0) { //mudat dps
            atual = rotacaoAEsquerda(atual);
            /*Senão se o nó atual ticor FB=2 e o filho da esquerda dele ticor Fb<0,
             troca o valor dele pelo resultado da rotação dupla a direita com ele*/
        } else if (atual.getBalanceamento() == 2 && atual.getEsq().getBalanceamento() < 0) {
            atual = rotacaoDuplaDireita(atual);
            /*Senão se o nó atual ticor FB=-2 e o filho da direita dele ticor Fb>0,
             troca o valor dele pelo resultado da rotação dupla a esquerda com ele*/
        } else if (atual.getBalanceamento() == -2 && atual.getDir().getBalanceamento() > 0) {
            atual = rotacaoDuplaEsquerda(atual);
        }
        /*Nessa parte aqui a recursão vai procurar por mais nós desbalanceados*/
        if (atual.getDir() != null) {
            balanceia(atual.getDir());
        }
        if (atual.getEsq() != null) {
            balanceia(atual.getEsq());
        }
        return atual; //Retorna a AVLNodeva raiz com seus filhotes balanceados
    }

}
