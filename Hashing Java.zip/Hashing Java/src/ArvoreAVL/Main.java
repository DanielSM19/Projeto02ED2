package ArvoreAVL;

public class Main {
    public static void main (String[] args){
        ArvoreAVL a = new ArvoreAVL();
        a.inserir(7, a.getRaiz());
        a.inserir(8, a.getRaiz());
        a.inserir(3, a.getRaiz());


        System.out.println("Antes de remoção: \n");
        a.imprime(a.getRaiz());
        a.remoção(7, a.getRaiz());
        System.out.println("Depois de remoção: \n");
        a.imprime(a.getRaiz());
    }
}
